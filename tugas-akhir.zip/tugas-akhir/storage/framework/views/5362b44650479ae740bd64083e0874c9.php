<?php $__env->startSection('content'); ?>
    <style>
        .absensi-container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .absensi-container h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #2c3e50;
            font-weight: 600;
        }

        .alert-success,
        .alert-error {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .clock-section {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            color: white;
        }

        .clock-section h4 {
            margin: 0 0 10px 0;
            opacity: 0.9;
        }

        .clock-section h2 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: bold;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .btn-absen {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            margin-right: 12px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-masuk {
            background-color: #28a745;
            color: white;
        }

        .btn-masuk:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
        }

        .btn-keluar {
            background-color: #dc3545;
            color: white;
        }

        .btn-keluar:hover {
            background-color: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
        }

        .btn-dev {
            background-color: #6f42c1;
            color: white;
            font-size: 12px;
            padding: 8px 16px;
        }

        .btn-dev:hover {
            background-color: #5a32a3;
        }

        .status-today {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            border-left: 4px solid #007bff;
        }

        .status-today h5 {
            margin: 0 0 8px 0;
            color: #495057;
        }

        .status-today p {
            margin: 0;
            font-size: 14px;
            color: #6c757d;
        }

        .complete-status {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
            text-align: center;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 14px 12px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }

        th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: #495057;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }

        tr:hover {
            background-color: #f8f9fa;
        }

        .badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            color: white;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .bg-danger {
            background-color: #dc3545;
        }

        .bg-success {
            background-color: #28a745;
        }

        .bg-warning {
            background-color: #ffc107;
            color: #212529;
        }

        .late-time {
            color: #dc3545;
            font-weight: bold;
            font-size: 12px;
        }

        .on-time {
            color: #28a745;
            font-size: 12px;
            font-weight: 500;
        }

        .time-late {
            color: #dc3545;
            font-weight: bold;
        }

        .time-normal {
            color: #28a745;
            font-weight: 500;
        }

        .no-data {
            text-align: center;
            color: #6c757d;
            font-style: italic;
            padding: 40px;
        }

        .dev-tools {
            background: #e9ecef;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            border-left: 4px solid #6f42c1;
        }

        .dev-tools h6 {
            margin: 0 0 10px 0;
            color: #6f42c1;
            font-weight: 600;
        }

        .working-hours {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #856404;
        }

        /* Tambahan untuk debug */
        .debug-info {
            background: #f8f9fa;
            border: 2px solid #6c757d;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            font-size: 12px;
            color: #495057;
        }

        @media (max-width: 768px) {
            .absensi-container {
                margin: 10px;
                padding: 20px;
            }

            table {
                font-size: 12px;
            }

            th,
            td {
                padding: 8px 6px;
            }

            .btn-absen {
                width: 100%;
                margin-right: 0;
                margin-bottom: 10px;
            }
        }
    </style>

    <div class="absensi-container">
        <h1>📋 Sistem Presensi Karyawan</h1>

        
        <?php if(session('success')): ?>
            <div class="alert-success">
                ✅ <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert-error">
                ❌ <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php
            $absenHariIni = $absensi->firstWhere('tanggal', \Carbon\Carbon::now()->toDateString());
            $jamBatas = '08:30:00';
        ?>

        
        

        
        <div class="clock-section">
            <h4 id="tanggal-hari-ini"></h4>
            <h4>⏰ Waktu Sekarang</h4>
            <h2 id="clock"></h2>
        </div>

        
        <div class="working-hours">
            <strong>ℹ️ Informasi:</strong> Jam masuk kerja adalah sebelum
            <strong><?php echo e(\Carbon\Carbon::parse($jamBatas)->format('H:i')); ?></strong>.
            Keterlambatan akan dicatat secara otomatis.
        </div>

        
        <?php if($absenHariIni): ?>
            <?php if($absenHariIni->jam_keluar): ?>
                
                <div class="complete-status">
                    ✅ Anda sudah menyelesaikan absensi hari ini
                    <br>
                    <small>
                        Masuk: <?php echo e(\Carbon\Carbon::parse($absenHariIni->jam)->format('H:i:s')); ?> |
                        Keluar: <?php echo e(\Carbon\Carbon::parse($absenHariIni->jam_keluar)->format('H:i:s')); ?>

                    </small>
                </div>
            <?php else: ?>
                
                <div class="status-today">
                    <h5>📅 Status Absensi Hari Ini</h5>
                    <p>
                        <strong>Masuk:</strong> <?php echo e(\Carbon\Carbon::parse($absenHariIni->jam)->format('H:i:s')); ?>

                        <?php if($absenHariIni->status === 'terlambat'): ?>
                            <span class="badge bg-danger">Terlambat</span>
                        <?php else: ?>
                            <span class="badge bg-success">Tepat Waktu</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>Keluar:</strong> <em>Belum absen keluar</em></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php if(app()->environment('local')): ?>
            <div class="dev-tools">
                <h6>🔧 Development Tools</h6>
                <?php if($absenHariIni): ?>
                    <form method="POST" action="<?php echo e(route('absensi.reset')); ?>" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-absen btn-dev"
                            onclick="return confirm('Reset data absensi hari ini?')">Reset Hari Ini</button>
                    </form>
                <?php endif; ?>
                <a href="<?php echo e(route('karyawan.absensi.check-ip')); ?>" target="_blank" class="btn-absen btn-dev">Cek IP</a>
            </div>
        <?php endif; ?>

        <?php
            use Carbon\Carbon;
            $today = Carbon::today()->format('Y-m-d');
            $absenHariIni = $absensi->first(function ($absen) use ($today) {
                return \Carbon\Carbon::parse($absen->tanggal)->format('Y-m-d') === $today;
            });
        ?>
        <div style="margin-bottom: 25px; text-align: center;">
            <?php if(!$absenHariIni): ?>
                
                <p style="margin-bottom: 15px; color: #495057; font-weight: 500;">
                    🚪 Silakan lakukan absen masuk
                </p>
                <form method="POST" action="<?php echo e(route('absensi.store')); ?>" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-absen btn-masuk">
                        🚪 Waktu Masuk
                    </button>
                </form>
            <?php elseif(is_null($absenHariIni->jam_keluar)): ?>
                
                <p style="margin-bottom: 15px; color: #495057; font-weight: 500;">
                    🏠 Anda sudah absen masuk, silakan absen keluar
                </p>
                <form method="POST" action="<?php echo e(route('absensi.keluar')); ?>" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-absen btn-keluar">
                        🏠 Waktu Pulang
                    </button>
                </form>
            <?php else: ?>
                
                <p style="margin-bottom: 15px; color: #28a745; font-weight: 500;">
                    ✅ Absensi hari ini sudah lengkap
                </p>
            <?php endif; ?>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>📅 Tanggal</th>
                    <th>🕐 Waktu Masuk</th>
                    <th>📊 Status</th>
                    <th>🕔 Waktu Pulang</th>
                    <th>⏱️ Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        // Perbaikan logika keterlambatan di view
                        $tanggal = \Carbon\Carbon::parse($item->tanggal)->toDateString();
                        $jamMasuk = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $tanggal . ' ' . $item->jam);
                        $jamBatas = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $tanggal . ' ' . '08:30:00');
                        $isTerlambat = $jamMasuk->gt($jamBatas);

                        $jamBatas = '08:30:00';

                        $jamBatasCarbon = \Carbon\Carbon::createFromFormat('H:i:s', $jamBatas);
                        $jamMasukCarbon = \Carbon\Carbon::createFromFormat('H:i:s', $item->jam);
                        $isTerlambat = $jamMasukCarbon->gt($jamBatasCarbon);

                        $durasiTerlambat = 'Tepat waktu';
                        if ($isTerlambat) {
                            $selisih = $jamMasukCarbon->diff($jamBatasCarbon);

                            if ($selisih->h > 0) {
                                $durasiTerlambat = $selisih->format('%h jam %i menit');
                            } else {
                                $durasiTerlambat = $selisih->format('%i menit');
                            }
                        }

                        // Gunakan status dari database jika ada, atau hitung ulang
                        $statusFromDB = $item->status ?? ($isTerlambat ? 'terlambat' : 'hadir');
                    ?>

                    <tr>
                        <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d/m/Y')); ?></td>
                        <td class="<?php echo e($isTerlambat ? 'time-late' : 'time-normal'); ?>">
                            <?php echo e(\Carbon\Carbon::parse($item->jam)->format('H:i:s')); ?>

                        </td>
                        <td>
                            <?php if($statusFromDB === 'terlambat'): ?>
                                <span class="badge bg-danger">Terlambat</span>
                            <?php else: ?>
                                <span class="badge bg-success">Hadir</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($item->jam_keluar): ?>
                                <?php echo e(\Carbon\Carbon::parse($item->jam_keluar)->format('H:i:s')); ?>

                            <?php else: ?>
                                <span style="color:#6c757d; font-style: italic;">Belum keluar</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($statusFromDB === 'terlambat'): ?>
                                <span class="late-time"><?php echo e($item->durasi_terlambat ?? $durasiTerlambat); ?></span>
                            <?php else: ?>
                                <span class="on-time"><?php echo e($durasiTerlambat); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="no-data">
                            📝 Belum ada data absensi
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <script>
        function updateClock() {
            const now = new Date();
            const jam = now.getHours().toString().padStart(2, '0');
            const menit = now.getMinutes().toString().padStart(2, '0');
            const detik = now.getSeconds().toString().padStart(2, '0');

            document.getElementById('clock').textContent = `${jam}:${menit}:${detik}`;

            const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
            const bulan = [
                "Januari", "Februari", "Maret", "April", "Mei", "Juni",
                "Juli", "Agustus", "September", "Oktober", "November", "Desember"
            ];

            const tanggal = `${hari[now.getDay()]}, ${now.getDate()} ${bulan[now.getMonth()]} ${now.getFullYear()}`;
            document.getElementById("tanggal-hari-ini").textContent = tanggal;
        }

        // Update clock setiap detik
        setInterval(updateClock, 1000);
        updateClock();

        // Auto refresh halaman setiap 5 menit untuk sinkronisasi data
        setTimeout(() => {
            location.reload();
        }, 300000); // 5 menit

        // Konfirmasi sebelum absen keluar
        document.addEventListener('DOMContentLoaded', function() {
            const keluarBtn = document.querySelector('button[type="submit"].btn-keluar');
            if (keluarBtn) {
                keluarBtn.addEventListener('click', function(e) {
                    if (!confirm('Apakah Anda yakin ingin melakukan absen keluar?')) {
                        e.preventDefault();
                    }
                });
            }
        });

        // Notifikasi browser untuk reminder absen
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }

        // Cek apakah sudah absen masuk hari ini
        <?php if(!$absenHariIni): ?>
            const now = new Date();
            const jam = now.getHours();
            const menit = now.getMinutes();

            // Reminder jika sudah lewat jam 08:30 tapi belum absen
            if ((jam > 8 || (jam === 8 && menit >= 30)) && jam < 12) {
                if ('Notification' in window && Notification.permission === 'granted') {
                    new Notification('Reminder Absensi', {
                        body: 'Jangan lupa untuk melakukan absen masuk!',
                        icon: '/favicon.ico'
                    });
                }
            }
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/karyawan/absensi/index.blade.php ENDPATH**/ ?>