<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="mb-3">Tambah Akun Karyawan</h4>
    <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.users.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button type="submit" class="btn btn-success">Simpan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/admin/users/create.blade.php ENDPATH**/ ?>