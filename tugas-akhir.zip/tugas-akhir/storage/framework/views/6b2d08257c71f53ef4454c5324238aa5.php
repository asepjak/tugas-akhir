<?php $__env->startSection('title', 'Riwayat Pengajuan Cuti & Dinas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="mb-3">Riwayat Pengajuan Cuti & Perjalanan Dinas</h4>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jenis</th>
                            <th>Periode</th>
                            <th>Alasan</th>
                            <th>Lampiran</th>
                            <th>Status</th>
                            <th>Waktu Pengajuan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->user->nama ?? $item->user->name); ?></td>
                                <td><?php echo e($item->keterangan); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_mulai)->format('d M Y')); ?> - <?php echo e(\Carbon\Carbon::parse($item->tanggal_selesai)->format('d M Y')); ?></td>
                                <td><?php echo e($item->alasan ?? '-'); ?></td>
                                <td>
                                    <?php if($item->file_surat): ?>
                                        <a href="<?php echo e(asset('storage/' . $item->file_surat)); ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                                            <i class="bi bi-file-earmark-text"></i> Lihat
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($item->status == 'Disetujui'): ?>
                                        <span class="badge bg-success"><?php echo e($item->status); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-danger"><?php echo e($item->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><small><?php echo e($item->created_at->format('d M Y H:i')); ?></small></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">Belum ada data pengajuan yang disetujui atau ditolak.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pimpinan-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/pimpinan/permissions/riwayat.blade.php ENDPATH**/ ?>