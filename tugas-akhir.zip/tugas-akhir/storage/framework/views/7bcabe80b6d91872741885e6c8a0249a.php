<?php $__env->startSection('title', 'Approval Cuti & Perjalanan Dinas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="mb-3">Persetujuan Cuti & Perjalanan Dinas</h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Tanggal Pengajuan</th>
                            <th>Alasan</th>
                            <th>Lampiran</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->user->nama ?? $item->user->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_mulai)->format('d M Y')); ?> - <?php echo e(\Carbon\Carbon::parse($item->tanggal_selesai)->format('d M Y')); ?></td>
                                <td><?php echo e($item->alasan ?? '-'); ?></td>
                                <td>
                                    <?php if($item->file_surat): ?>
                                        <a href="<?php echo e(asset('storage/' . $item->file_surat)); ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                                            <i class="bi bi-file-earmark-text"></i> Lihat
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-primary"><?php echo e($item->keterangan); ?></span><br>
                                    <span class="badge bg-warning text-dark"><?php echo e($item->status); ?></span>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('pimpinan.permissions.updateStatus', $item->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="Disetujui">
                                        <button type="submit" class="btn btn-success btn-sm">Setujui</button>
                                    </form>
                                    <form action="<?php echo e(route('pimpinan.permissions.updateStatus', $item->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="Ditolak">
                                        <button type="submit" class="btn btn-danger btn-sm">Tolak</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">Tidak ada pengajuan cuti atau perjalanan dinas yang menunggu.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pimpinan-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/pimpinan/permissions/index.blade.php ENDPATH**/ ?>