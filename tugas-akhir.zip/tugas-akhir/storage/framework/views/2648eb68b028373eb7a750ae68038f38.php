<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-bold mb-0"><i class="fas fa-user-clock me-2"></i>Data Izin Karyawan</h4>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered align-middle mb-0">
                        <thead class="bg-dark text-white text-center">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Jenis Izin</th>
                                <th>Alasan</th>
                                <th>Mulai</th>
                                <th>Selesai</th>
                                <th>Surat</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="text-center">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-start"><?php echo e($item->user->nama ?? $item->user->name); ?></td>
                                    <td><span class="badge bg-info text-dark"><?php echo e($item->keterangan); ?></span></td>
                                    <td class="text-start"><?php echo e($item->alasan); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_mulai)->format('d M Y')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_selesai)->format('d M Y')); ?></td>
                                    <td>
                                        <?php if($item->file_surat): ?>
                                            <a href="<?php echo e(asset('storage/' . $item->file_surat)); ?>" target="_blank"
                                                class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-file-alt me-1"></i>Lihat
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge
                                            <?php if($item->status == 'Menunggu'): ?> bg-warning
                                            <?php elseif($item->status == 'Disetujui'): ?> bg-success
                                            <?php else: ?> bg-danger <?php endif; ?>">
                                            <?php echo e($item->status); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if($item->status == 'Menunggu'): ?>
                                            <?php if(in_array($item->keterangan, ['Sakit', 'Izin'])): ?>
                                                <div class="d-flex flex-column gap-1">
                                                    <form action="<?php echo e(route('permissions.updateStatus', $item->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="Disetujui">
                                                        <button type="submit" class="btn btn-sm btn-success w-100">
                                                            <i class="fas fa-check me-1"></i>Setujui
                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(route('permissions.updateStatus', $item->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="Ditolak">
                                                        <button type="submit" class="btn btn-sm btn-danger w-100">
                                                            <i class="fas fa-times me-1"></i>Tolak
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php else: ?>
                                                <em class="text-muted">Menunggu verifikasi pimpinan</em>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted"><i class="fas fa-check-circle me-1"></i><?php echo e($item->status); ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted py-4">
                                        <i class="fas fa-info-circle me-1"></i>Belum ada data izin.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/admin/verifikasi/permissions.blade.php ENDPATH**/ ?>