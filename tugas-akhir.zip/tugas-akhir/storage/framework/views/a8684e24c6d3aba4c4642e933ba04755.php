<?php $__env->startSection('title', '404 Not Found'); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center my-5">
    <h1 class="display-1">404</h1>
    <p class="lead">Halaman tidak ditemukan atau sedang dalam perbaikan.</p>
    <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Kembali ke Beranda</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts-error', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/errors/404.blade.php ENDPATH**/ ?>