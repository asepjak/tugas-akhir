<?php $__env->startSection('title', 'Manajemen User'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="fw-bold text-uppercase text-center mb-4">Manajemen User</h4>

    <!-- Alert Messages -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Tabel Desktop -->
    <div class="table-responsive d-none d-md-block">
        <table class="table table-bordered table-striped">
            <thead class="table-dark text-center">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Token</th> <!-- kolom token opsional -->
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e(ucfirst($user->role)); ?></td>
                        <td><?php echo e($user->reset_token ?? '-'); ?></td>
                        <td class="d-flex gap-1 justify-content-center">
                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <form action="<?php echo e(route('admin.users.resetToken', $user->id)); ?>" method="POST" onsubmit="return confirm('Reset token untuk <?php echo e($user->name); ?>?')">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-key"></i> Reset Token
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">Tidak ada data user.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Tampilan Mobile -->
    <div class="d-md-none">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card mb-3">
                <div class="card-body row">
                    <div class="col-8">
                        <h5 class="card-title"><?php echo e($user->name); ?></h5>
                        <p class="card-text mb-1"><strong>Email:</strong> <?php echo e($user->email); ?></p>
                        <p class="card-text mb-1"><strong>Role:</strong> <?php echo e(ucfirst($user->role)); ?></p>
                        <p class="card-text mb-1"><strong>Token:</strong> <?php echo e($user->reset_token ?? '-'); ?></p>
                    </div>
                    <div class="col-4 text-end">
                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-sm btn-warning">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form action="<?php echo e(route('admin.users.resetToken', $user->id)); ?>" method="POST" onsubmit="return confirm('Reset token untuk <?php echo e($user->name); ?>?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-danger mt-1">
                                <i class="fas fa-key"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center">Tidak ada data user.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/admin/users/index.blade.php ENDPATH**/ ?>