<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Rekap Absensi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            color: #000;
        }
        h2, h4 {
            text-align: center;
            margin: 0;
        }
        .sub-title {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        table th, table td {
            border: 1px solid #000;
            padding: 8px 10px;
            text-align: center;
        }
        table th {
            background-color: #f0f0f0;
        }
        @media print {
            @page { margin: 25mm; }
        }
    </style>
</head>
<body onload="window.print()">
    <h2>REKAP ABSENSI KARYAWAN</h2>
    <div class="sub-title">
        Bulan <?php echo e(\Carbon\Carbon::createFromDate($tahun, (int) $bulan, 1)->locale('id')->isoFormat('MMMM')); ?> <?php echo e($tahun); ?>

    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Hadir</th>
                <th>Izin</th>
                <th>Sakit</th>
                <th>Terlambat</th>
                <th>Tanpa Keterangan</th>
                <th>Total Absen</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($item['user']->nama ?? $item['user']->name); ?></td>
                    <td><?php echo e($item['jumlah_hadir']); ?></td>
                    <td><?php echo e($item['jumlah_izin']); ?></td>
                    <td><?php echo e($item['jumlah_sakit']); ?></td>
                    <td><?php echo e($item['jumlah_terlambat']); ?></td>
                    <td><?php echo e($item['tanpa_keterangan']); ?></td>
                    <td><?php echo e($item['total_hadir_efektif']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">Tidak ada data.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/admin/rekap/print.blade.php ENDPATH**/ ?>