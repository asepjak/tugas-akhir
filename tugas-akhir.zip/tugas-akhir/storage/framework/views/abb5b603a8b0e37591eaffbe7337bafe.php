<?php $__env->startSection('title', 'Dashboard Karyawan'); ?>

<?php $__env->startPush('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .status-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-radius: 15px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .status-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .fade-in {
            animation: fadeIn 0.6s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .table td, .table th {
            vertical-align: middle;
        }

        .badge {
            font-size: 0.9rem;
            padding: 0.5em 0.75em;
            border-radius: 0.5rem;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f9f9f9;
        }

        .table-striped tbody tr:hover {
            background-color: #f1f1f1;
        }

        .table th {
            background-color: #007bff;
            color: white;
        }

        .table td {
            color: #495057;
        }

        .alert {
            border-radius: 0.5rem;
        }

        .filter-info {
            background-color: #e7f3ff;
            border: 1px solid #b3d9ff;
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            margin-bottom: 1rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5 fade-in">
        
        <div class="text-center mb-5">
            <h2 class="fw-bold text-uppercase">Status Presensi Bulan Ini</h2>
            <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="d-flex flex-wrap justify-content-center gap-3 mt-3">
                <select name="month" class="form-select w-auto">
                    <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::create()->month($m)->isoFormat('MMMM')); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="number" name="year" value="<?php echo e($year); ?>" class="form-control w-auto" min="2000" max="<?php echo e(now()->year); ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-search"></i> Filter
                </button>
            </form>
        </div>

        
        <div class="row justify-content-center g-4">
            <div class="col-md-3">
                <div class="card status-card text-center shadow-sm border-0">
                    <div class="card-body py-4">
                        <img src="<?php echo e(asset('assets/approval-stamp.png')); ?>" width="50" class="mb-3">
                        <h2 class="fw-bold text-success"><?php echo e($hadir); ?></h2>
                        <p class="text-muted mb-0">Hadir</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card status-card text-center shadow-sm border-0">
                    <div class="card-body py-4">
                        <img src="<?php echo e(asset('assets/first-aid-kit.png')); ?>" width="50" class="mb-3">
                        <h2 class="fw-bold text-warning"><?php echo e($sakit); ?></h2>
                        <p class="text-muted mb-0">Sakit</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card status-card text-center shadow-sm border-0">
                    <div class="card-body py-4">
                        <img src="<?php echo e(asset('assets/off.png')); ?>" width="50" class="mb-3">
                        <h2 class="fw-bold text-info"><?php echo e($izin); ?></h2>
                        <p class="text-muted mb-0">Izin</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card status-card text-center shadow-sm border-0">
                    <div class="card-body py-4">
                        <img src="<?php echo e(asset('assets/calendar.png')); ?>" width="50" class="mb-3">
                        <h2 class="fw-bold text-secondary"><?php echo e($cuti); ?></h2>
                        <p class="text-muted mb-0">Cuti</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card status-card text-center shadow-sm border-0">
                    <div class="card-body py-4">
                        <i class="bi bi-truck-front-fill fs-1 text-primary mb-3"></i>
                        <h2 class="fw-bold text-primary"><?php echo e($perjalanan ?? 0); ?></h2>
                        <p class="text-muted mb-0">Perjalanan</p>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="mt-5">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold">Riwayat Ajuan</h4>
            </div>

            
            <div class="filter-info fade-in">
                <div class="d-flex align-items-center">
                    <i class="bi bi-info-circle me-2"></i>
                    <span>
                        Menampilkan data untuk bulan
                        <strong><?php echo e(\Carbon\Carbon::create()->month($month)->isoFormat('MMMM')); ?> <?php echo e($year); ?></strong>
                    </span>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success fade-in">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="table-responsive shadow-sm rounded fade-in">
                <table class="table table-striped table-hover align-middle" id="izinTable">
                    <thead class="table-primary">
                        <tr>
                            <th>Keterangan</th>
                            <th>Alasan</th>
                            <th>Mulai</th>
                            <th>Selesai</th>
                            <th>Status</th>
                            <th>Lampiran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $izin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($izin->keterangan); ?></td>
                                <td><?php echo e($izin->alasan); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($izin->tanggal_mulai)->format('d M Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($izin->tanggal_selesai)->format('d M Y')); ?></td>
                                <td>
                                    <?php if($izin->status == 'Menunggu'): ?>
                                        <span class="badge bg-warning text-dark">Menunggu</span>
                                    <?php elseif($izin->status == 'Disetujui'): ?>
                                        <span class="badge bg-success">Diterima</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($izin->file_surat): ?>
                                        <a href="<?php echo e(asset('storage/' . $izin->file_surat)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-file-earmark-text"></i> Lihat
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">
                                    Belum ada data ajuan untuk bulan <?php echo e(\Carbon\Carbon::create()->month($month)->isoFormat('MMMM')); ?> <?php echo e($year); ?>.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#izinTable').DataTable({
                language: {
                    search: "Cari:",
                    lengthMenu: "Tampilkan _MENU_ data",
                    zeroRecords: "Tidak ditemukan data yang cocok",
                    info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
                    paginate: {
                        previous: "Sebelumnya",
                        next: "Berikutnya"
                    }
                },
                order: [[2, 'desc']]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/dashboard/karyawan.blade.php ENDPATH**/ ?>