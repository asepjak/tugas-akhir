<div class="mb-3">
    <label>Nama</label>
    <input type="text" name="nama" class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>"
        value="<?php echo e(old('nama', $user->nama ?? '')); ?>">
    <?php if($errors->has('nama')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('nama')); ?></div>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>Email</label>
    <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
        value="<?php echo e(old('email', $user->email ?? '')); ?>">
    <?php if($errors->has('email')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>Username</label>
    <input type="text" name="username" class="form-control <?php echo e($errors->has('username') ? 'is-invalid' : ''); ?>"
        value="<?php echo e(old('username', $user->username ?? '')); ?>">
    <?php if($errors->has('username')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('username')); ?></div>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>No HP</label>
    <input type="text" name="no_hp" class="form-control <?php echo e($errors->has('no_hp') ? 'is-invalid' : ''); ?>"
        value="<?php echo e(old('no_hp', $user->no_hp ?? '')); ?>">
    <?php if($errors->has('no_hp')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('no_hp')); ?></div>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>Alamat</label>
    <input type="text" name="alamat" class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid' : ''); ?>"
        value="<?php echo e(old('alamat', $user->alamat ?? '')); ?>">
    <?php if($errors->has('alamat')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('alamat')); ?></div>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>Jabatan</label>
    <select name="jabatan" class="form-select <?php echo e($errors->has('jabatan') ? 'is-invalid' : ''); ?>">
        <option value="">-- Pilih Jabatan --</option>
        <?php $__currentLoopData = ['Admin', 'Staff', 'Manajer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($j); ?>" <?php echo e(old('jabatan', $user->jabatan ?? '') == $j ? 'selected' : ''); ?>><?php echo e($j); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($errors->has('jabatan')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('jabatan')); ?></div>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>Status</label>
    <select name="status" class="form-select <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>">
        <option value="">-- Pilih Status --</option>
        <?php $__currentLoopData = ['Aktif', 'Tidak Aktif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s); ?>" <?php echo e(old('status', $user->status ?? '') == $s ? 'selected' : ''); ?>><?php echo e($s); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if($errors->has('status')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('status')); ?></div>
    <?php endif; ?>
</div>

<div class="mb-3">
    <label>Foto (Opsional)</label>
    <input type="file" name="foto" class="form-control <?php echo e($errors->has('foto') ? 'is-invalid' : ''); ?>">
    <?php if($errors->has('foto')): ?>
        <div class="invalid-feedback"><?php echo e($errors->first('foto')); ?></div>
    <?php endif; ?>
</div>


<?php if(!isset($user)): ?>
    <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('password')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
        <?php endif; ?>
    </div>
    <div class="mb-3">
        <label>Konfirmasi Password</label>
        <input type="password" name="password_confirmation" class="form-control">
    </div>
<?php else: ?>
    <div class="mb-3">
        <label>Password Baru (opsional)</label>
        <input type="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>">
        <?php if($errors->has('password')): ?>
            <div class="invalid-feedback"><?php echo e($errors->first('password')); ?></div>
        <?php endif; ?>
    </div>
    <div class="mb-3">
        <label>Konfirmasi Password Baru</label>
        <input type="password" name="password_confirmation" class="form-control">
    </div>
<?php endif; ?>
<?php /**PATH D:\semester 6\tugas-akhir\tugas-akhir\resources\views/admin/users/form.blade.php ENDPATH**/ ?>